console.log("Hello World");

// imprimir na tela numeros de 1 até 10
// ini = ini + 1
// ini += 1
// ini++

var ini = 1
var fim = 10

while(ini <= fim)
{
    console.log(ini);
    ini += 1;
}

// usando for
for(var ini = 9; ini >=1; ini -= 1)
{
    console.log(ini)
}