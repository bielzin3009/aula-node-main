function impares(quant) {
    let n1 = 1;
    let somaimpar = 2;
    let final = 50
    
    for(n1 <= final; proximo = n1 + somaimpar;) {
    
    n1 = proximo
    console.log(proximo);

    }
}

impares(quant)